package Book;

public enum Category {
    ADVENTURE,SCIENCE_FICTION,NARRATIVE,CLASSICS,HORROR
}
