package Book;

import java.time.LocalDate;

public class Autore {
    private int idNumerico;
    private String name;
    private String surname;
    private LocalDate birthday;
    private String nazionalita;
    private String lingua;

    public Autore(int idNumerico, String name, String surname, LocalDate birthday, String nazionalita, String lingua) {
        this.idNumerico = idNumerico;
        this.name = name;
        this.surname = surname;
        this.birthday = birthday;
        this.nazionalita = nazionalita;
        this.lingua = lingua;
    }

    public double getPage(){
        return getPage();
    }

    public String getLingua() {
        return lingua;
    }

    public String getNazionalita() {
        return nazionalita;
    }

    public LocalDate getBirthday() {
        return birthday;
    }

    public String getSurname() {
        return surname;
    }

    public String getName() {
        return name;
    }

    public static int getIdNumerico() {
        return idNumerico;
    }
}
