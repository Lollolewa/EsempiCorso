package Book;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Book {
    private int idNum;
    private String titolo;
    private double peso;
    private int numPage;
    private double costo;
    private LocalDate datePublication;
    private Category category;
    private List<Autore> listaAutore;
    private String lingua;

    public Book(int idNum, String titolo, double peso, int numPage, double costo, LocalDate datePublication, Category category, List<Autore> listaAutore, String lingua) {
        this.idNum = idNum;
        this.titolo = titolo;
        this.peso = peso;
        this.numPage = numPage;
        this.costo = costo;
        this.datePublication = datePublication;
        this.category = category;
        this.listaAutore= new ArrayList<>();
        this.lingua = lingua;
    }


    public int getIdNum() {
        return idNum;
    }

    public String getTitolo() {
        return titolo;
    }

    public double getPeso() {
        return peso;
    }

    public int getNumPage() {
        return numPage;
    }

    public double getCosto() {
        return costo;
    }

    public LocalDate getDatePublication() {
        return datePublication;
    }

    public Category getCategory() {
        return category;
    }

    public List<Autore> getListaAutore() {
        return listaAutore;
    }

    public String getLingua() {
        return lingua;
    }
}
