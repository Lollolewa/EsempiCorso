package Book;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

public class BookRepository {
    private List<Book> libri = List.of(
            new Book(1, "La Fame", 3.5, 1600, 25.00, LocalDate.of(1955, 06, 12), Category.
                    HORROR, List.of(new Autore(1, "Marco", "Falconetti", LocalDate.of(1920, 8, 4), "Italiana", "Bene")), "discreto"),
            new Book(2, "La morte", 1.5, 100, 50.00, LocalDate.of(1975, 06, 12), Category.NARRATIVE,
                    List.of(new Autore(2, "Carlotta", "Pisano", LocalDate.of(1950, 8, 4), "Italiana", "Tedesco")), "Tedesco"));


    public List<Book> findBookByCategory(Category c) {
        return libri.stream().filter(l -> l.getCategory().equals(c)).toList();
    }

    public List<Book> findByTitleLikeAndPublishedBetween(String word, LocalDate start, LocalDate end) {

        var bookDate = libri.stream().filter(l -> l.getDatePublication().isBefore(end) && l.getDatePublication().isAfter(start)).toList();
        var bookWord = bookDate.stream().filter(l -> l.getTitolo().contains(word)).sorted(Comparator.comparingDouble(Book::getCosto)).toList();//lista che contiene libri per parola
        return bookWord;
    }

    public double findAvgCostByLanguage(String language) { //average calcola la media
        var libriInLingua = libri.stream().filter(l -> l.getLingua().contains(language)).toList();
        return libriInLingua.isEmpty() ? 0 : libriInLingua.stream().mapToDouble(Book::getCosto).sum() / libriInLingua.size();

    }

    public List<Book> findByAuthorId(int id) {
        return libri.stream().filter(l -> l.getListaAutore().stream().anyMatch(autore -> autore.getIdNumerico() == id)).toList();
    }

    public List<Book> findByNumAuthor(List<Autore> autores) {
        return libri.stream().filter(l -> l.getListaAutore().size() > 1).sorted(Comparator.comparingInt((Book l) -> l.getListaAutore().size()).reversed()).toList();
    }

    public List<Autore> findAuthorByCategory(Category category) {
       return libri.stream().filter(b->b.getCategory().equals(category)).flatMap(b ->b.getListaAutore().stream())
                .sorted(Comparator.comparing(Autore::getSurname).thenComparing(Autore::getName)).distinct().toList();
    }

    public double costoMedio(Book b, List<Book> libri){
        return libri.stream().mapToDouble(Book::getCosto).sum() / libri.size();

    }

    public int findPageWrittenByAuthoreById(int id){
        return libri.stream().filter(l -> l.getListaAutore().stream()
                .anyMatch(autore -> autore.getIdNumerico() == id))
                .mapToInt(l->l.getNumPage()).sum();

    }

    public int findPageWrittenByCategory(Category category){
        return libri.stream().filter(l->l.getCategory().equals(category)).mapToInt(l->l.getNumPage()).sum();
    }

    public double findBookWrittenByAuthorByLanguageFrancesce() {
        return libri.stream().filter(l -> l.getListaAutore().stream().filter(autore -> autore.getLingua().equalsIgnoreCase("Francese"))
                .mapToDouble(Book::getCosto).average().orElse(0.0));
    }
        //dammi il numero totale di pagine che sono state scritte da un autore con un certo id;
    //dammi il numeto totale di pagine che sono state scritte per una certa caterogia di pagine;
    //dammi il valore medio del prezzo dei libri scritti da un autore che parla la lingua francese;
        // dammi una funzione di un autore che ha scritto più libri e nel caso ci fosse un parimerito di un autore random
}

